<?php ### RENAME TO: configuration.php ###
//====================================================================
//  Copyright � 2008 SWIFT Panel All Rights Reserved.
//====================================================================

//*************************************************************************************************

	### REQUIRED SETTINGS ###
	
	// DO NOT CHANGE
	define('LICENSE', 'IgnoreMe');
    // DO NOT CHANGE  
	
	// DBHOST is the MySQL Database Hostname
	// Default: "localhost"
	define('DBHOST', 'localhost');
	
	// DBNAME is the MySQL Database Name
	define('DBNAME', 'name');
	
	// DBUSER is the MySQL Database Username
	define('DBUSER', 'user');
	
	// DBPASSWORD is the MySQL Database Password
	define('DBPASSWORD', 'password');

//*************************************************************************************************

//====================================================================
//  Copyright � 2008 SWIFT Panel All Rights Reserved.
//====================================================================
?>